package com.example.secretniyreceptpelmeney;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void regist(View view) {
        Intent intent1 = new Intent(this, SecondActivity.class);
        startActivity(intent1);

    }

    public void meow(View view) {
        String text1 = getIntent().getStringExtra("my login");
        String text2 = getIntent().getStringExtra("my parrol");
        Toast.makeText(this, text1 + text2 + "", Toast.LENGTH_SHORT).show();
        Intent intent4 = new Intent(this, MainActivity.class);
        intent4.putExtra("text1", text1);
        intent4.putExtra("text2", text2);
    }

    public void voi(View view) {
        Intent intent4 = new Intent(this, ThirdActivity.class);
        startActivity(intent4);
    }
}