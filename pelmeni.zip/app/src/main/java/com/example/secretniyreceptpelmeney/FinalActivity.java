package com.example.secretniyreceptpelmeney;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

public class FinalActivity extends AppCompatActivity {
    TextView logim;
    ImageButton cat1;
    ImageButton cat2;
    ImageButton cat3;
    ImageButton cat4;
    ImageButton cat5;
    ImageButton cat6;
    ImageButton cat7;
    ImageButton cat8;
    ImageButton cat9;
    ImageButton cat10;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_final);
        setupUI();
        String text1 = getIntent().getStringExtra("my login");
        logim.setText(text1);

    }

    public void back(View view) {
        Intent intent2 = new Intent(this, MainActivity.class);
        startActivity(intent2);
    }

    private void setupUI(){
        logim =  findViewById(R.id.logim);
        cat1 =  findViewById(R.id.cat1);
        cat2 =  findViewById(R.id.cat2);
        cat3 =  findViewById(R.id.cat3);
        cat4 =  findViewById(R.id.cat4);
        cat5 =  findViewById(R.id.cat5);
        cat6 =  findViewById(R.id.cat6);
        cat7 =  findViewById(R.id.cat7);
        cat8 =  findViewById(R.id.cat8);
        cat9 =  findViewById(R.id.cat9);
        cat10 =  findViewById(R.id.cat10);
    }

    public void cat1(View view) {
        cat1.setBackground(Drawable.createFromPath("@color/inv"));
    }

    public void cat2(View view) {
        cat2.setBackground(Drawable.createFromPath("@color/inv"));
    }

    public void cat3(View view) {
        cat3.setBackground(Drawable.createFromPath("@color/inv"));
    }

    public void cat4(View view) {
        cat4.setBackground(Drawable.createFromPath("@color/inv"));
    }

    public void cat5(View view) {
        cat5.setBackground(Drawable.createFromPath("@color/inv"));
    }

    public void cat6(View view) {
        cat6.setBackground(Drawable.createFromPath("@color/inv"));
    }

    public void cat7(View view) {
        cat7.setBackground(Drawable.createFromPath("@color/inv"));
    }

    public void cat8(View view) {
        cat8.setBackground(Drawable.createFromPath("@color/inv"));
    }

    public void cat9(View view) {
        cat9.setBackground(Drawable.createFromPath("@color/inv"));
    }

    public void cat10(View view) {
        cat10.setBackground(Drawable.createFromPath("@color/inv"));
    }
}