package com.example.secretniyreceptpelmeney;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class SecondActivity extends AppCompatActivity {
    EditText parrol_pov_ET;
    EditText login_ET;
    EditText parrol_ET;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        setupUI();
    }
    public void back(View view) {
        Intent intent2 = new Intent(this, MainActivity.class);
        startActivity(intent2);
    }
    private void setupUI(){
        parrol_pov_ET =  findViewById(R.id.parrol_pov);
        parrol_ET =  findViewById(R.id.parrol);
        login_ET =  findViewById(R.id.login);
    }

    public void zareg(View view) {
        String none = "";
        String login = login_ET.getText().toString();
        String parrol = parrol_ET.getText().toString();
        String parrol_pov = parrol_pov_ET.getText().toString();
        if ((login.equals(none))|(parrol.equals(none))|(parrol_pov.equals(none))) Toast.makeText(this, "Все поля должны быть заполнены", Toast.LENGTH_SHORT).show();
        else if (!(parrol.equals(parrol_pov))) Toast.makeText(this, "Вы неверно ввели повторно пароль", Toast.LENGTH_SHORT).show();
        else {
            Toast.makeText(this, "Вы успешно зарегестрированы", Toast.LENGTH_SHORT).show();
            Intent intent3 = new Intent(this, FinalActivity.class);
            intent3.putExtra("my login", login);
            startActivity(intent3);
        }


    }
}