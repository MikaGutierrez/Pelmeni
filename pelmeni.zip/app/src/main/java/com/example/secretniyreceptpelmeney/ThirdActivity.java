package com.example.secretniyreceptpelmeney;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class ThirdActivity extends AppCompatActivity {
    EditText parrol_end_ET;
    EditText login_end_ET;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);
        setupUI();
    }

    public void back(View view) {
        Intent intent5 = new Intent(this, MainActivity.class);
        startActivity(intent5);
    }


    private void setupUI(){
        parrol_end_ET =  findViewById(R.id.parrol_end);
        login_end_ET =  findViewById(R.id.login_end);
    }

    public void voiti_rec(View view) {
        String none = "";
        String login = login_end_ET.getText().toString();
        String parrol = parrol_end_ET.getText().toString();
        if ((login.equals(none))|(parrol.equals(none))) Toast.makeText(this, "Все поля должны быть заполнены", Toast.LENGTH_SHORT).show();
        else if ((login.equals("Admin"))&&(parrol.equals("Pelmen"))){
            Toast.makeText(this, "Вы успешно вошли", Toast.LENGTH_SHORT).show();
            Intent intent3 = new Intent(this, FinalActivity.class);
            startActivity(intent3);
        }
        else Toast.makeText(this, "Не правильный логин или пароль", Toast.LENGTH_SHORT).show();
    }
}